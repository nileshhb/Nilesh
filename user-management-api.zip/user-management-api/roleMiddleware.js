const roleMiddleware = (roles) => (req, res, next) => {
    console.log("User Role from Token:", req.user.role);
    console.log("Allowed Roles:", roles);

    const userRole = req.user.role.toLowerCase();
    if (!roles.includes(userRole)) {
        return res.status(403).json({ message: "Access Denied. Insufficient Permissions." });
    }
    next();
};

module.exports = { roleMiddleware };
