const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.memoryStorage();
const upload = multer({ storage });

require("dotenv").config();

const { authMiddleware } = require("./authMiddleware");
const { roleMiddleware } = require("./roleMiddleware");
const User = require("./models/User");

const app = express();
app.use(express.json({ limit: "50mb" })); //Increase JSON body size limit 

app.use(express.urlencoded({ limit: "50mb", extended: true })); //Increase URL-encoded form data limit
app.use(bodyParser.json());
app.use(cors());

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI)
.then(() => console.log("Connected to MongoDB Atlas!"))
.catch(err => console.error("MongoDB Atlas connection error:", err));

// Signup Route
app.post("/api/auth/signup", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({ name, email, password: hashedPassword, role });
        await newUser.save();

        res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering user", error });
    }
});

// Login Route
app.post("/api/auth/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ message: "Invalid email or password" });
        }

        const token = jwt.sign(
            { userId: user._id, role: user.role }, // Ensure role is included
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );

        console.log("Generated Token:", token); // Debugging
        res.json({ token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error });
    }
});


// Protected Route: Get Users (Only Admin and Supervisor)
app.get("/api/users", authMiddleware, roleMiddleware(["admin", "supervisor"]), async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Error fetching users" });
    }
});

// Protected Route: Delete User (Only Admin)
app.delete("/api/users/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if (!deletedUser) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json({ message: "User deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting user" });
    }
});

// Protected Route: Update User (Admin or Supervisor)
app.put("/api/users/:id", authMiddleware, roleMiddleware(["admin", "supervisor"]), async (req, res) => {
    try {
        const updatedUser = await User.findByIdAndUpdate(
            req.params.id,
            { name: req.body.name, email: req.body.email, role: req.body.role },
            { new: true }
        );
        if (!updatedUser) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json(updatedUser);
    } catch (error) {
        res.status(500).json({ message: "Error updating user" });
    }
});

app.post("/api/users/:id/upload", upload.single('image'), async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        if (!req.file) {
            return res.status(400).json({ message: "No image uploaded" });
        }

        // Convert Image to Base64 and Store in DB
        user.profileImage = {
            data: req.file.buffer,
            contentType: req.file.mimetype
        };

        await user.save();
        res.json({ message: "Image uploaded successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error uploading image", error });
    }
});

// API to Fetch Profile Image
app.get("/api/users/:id/image", async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user || !user.profileImage.data) {
            return res.status(404).json({ message: "Image not found" });
        }

        res.contentType(user.profileImage.contentType);
        res.send(user.profileImage.data);
    } catch (error) {
        res.status(500).json({ message: "Error fetching image", error });
    }
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
