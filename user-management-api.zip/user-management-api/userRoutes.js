const express = require("express");
const User = require("./models/User");
const { authMiddleware, roleMiddleware } = require("./authMiddleware");

const router = express.Router();

// Get all users (Admin only)
router.get("/", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Error fetching users" });
    }
});

// Get workers (Admin & Supervisor)
router.get("/workers", authMiddleware, roleMiddleware(["admin", "supervisor"]), async (req, res) => {
    try {
        const workers = await User.find({ role: "worker" });
        res.json(workers);
    } catch (error) {
        res.status(500).json({ message: "Error fetching workers" });
    }
});

// Update user (Self-update for Workers, Admin/Supervisor can update others)
router.put("/:id", authMiddleware, async (req, res) => {
    if (req.user.role === "worker" && req.user.id !== req.params.id) {
        return res.status(403).json({ message: "Workers can only update their own profile" });
    }

    if (req.user.role === "supervisor") {
        const targetUser = await User.findById(req.params.id);
        if (!targetUser || targetUser.role !== "worker") {
            return res.status(403).json({ message: "Supervisors can only manage workers" });
        }
    }

    try {
        const updatedUser = await User.findByIdAndUpdate(req.params.id, { name: req.body.name, email: req.body.email }, { new: true });
        res.json(updatedUser);
    } catch (error) {
        res.status(500).json({ message: "Error updating user" });
    }
});

// Delete user (Admin only, Supervisor can delete Workers)
router.delete("/:id", authMiddleware, async (req, res) => {
    try {
        const targetUser = await User.findById(req.params.id);
        if (!targetUser) return res.status(404).json({ message: "User not found" });

        if (req.user.role === "supervisor" && targetUser.role !== "worker") {
            return res.status(403).json({ message: "Supervisors can only delete workers" });
        }

        if (req.user.role !== "admin" && req.user.role !== "supervisor") {
            return res.status(403).json({ message: "Access Denied" });
        }

        await User.findByIdAndDelete(req.params.id);
        res.json({ message: "User deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting user" });
    }
});

module.exports = router;
